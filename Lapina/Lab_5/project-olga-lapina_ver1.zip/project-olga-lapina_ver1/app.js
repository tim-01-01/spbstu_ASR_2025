// ===== ОБЩИЕ ФУНКЦИИ =====

// Проверка аутентификации
function checkAuth() {
    if (window.location.pathname.includes('index.html')) {
        const isAuthenticated = sessionStorage.getItem('isAuthenticated');
        if (!isAuthenticated) {
            window.location.href = 'auth.html';
        }
    }
}

// Инициализация приложения
function initApp() {
    // Проверка на какой странице находимся
    if (window.location.pathname.includes('auth.html')) {
        initAuthPage();
    } else if (window.location.pathname.includes('index.html')) {
        initDashboard();
    }
}

// ===== СТРАНИЦА АУТЕНТИФИКАЦИИ =====

function initAuthPage() {
    const authForm = document.getElementById('authForm');
    
    if (authForm) {
        authForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const login = document.getElementById('login').value;
            const password = document.getElementById('password').value;
            
            // Проверка демо-доступа
            if (login === authCredentials.login && password === authCredentials.password) {
                // Успешная аутентификация
                sessionStorage.setItem('isAuthenticated', 'true');
                sessionStorage.setItem('userLogin', login);
                
                // Перенаправление на главную страницу
                window.location.href = 'index.html';
            } else {
                // Ошибка аутентификации
                showAuthError();
            }
        });
    }
}

function showAuthError() {
    // Создаем или находим элемент для ошибки
    let errorElement = document.querySelector('.auth-error');
    
    if (!errorElement) {
        errorElement = document.createElement('div');
        errorElement.className = 'auth-error';
        errorElement.style.cssText = `
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: var(--radius);
            margin-top: 15px;
            border: 1px solid #f5c6cb;
        `;
        
        const form = document.getElementById('authForm');
        form.appendChild(errorElement);
    }
    
    errorElement.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i>
        Неверный логин или пароль. Используйте демо-доступ: Логин: lapina.ok / Пароль: study2024
    `;
    
    // Убираем ошибку через 5 секунд
    setTimeout(() => {
        errorElement.style.opacity = '0';
        setTimeout(() => errorElement.remove(), 300);
    }, 5000);
}

// ===== ГЛАВНАЯ СТРАНИЦА =====

function initDashboard() {
    checkAuth();
    
    // Инициализация компонентов
    initNavigation();
    initUserProfile();
    initDashboardWidgets();
    initProgressChart();
    initProgressTable();
    initLibrary();
    initLectures();
    initTasks();
    initUploadForm();
    initArchiveTable();
    initModal();
    initLogout();
    
    // Добавляем аватар пользователя
    updateUserAvatar();
}

// Навигация
function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const menuToggle = document.getElementById('menuToggle');
    const nav = document.querySelector('.nav');
    
    // Плавная прокрутка к секциям
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                // Обновляем активную ссылку
                navLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
                
                // Прокручиваем к секции
                window.scrollTo({
                    top: targetSection.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Закрываем мобильное меню если открыто
                if (nav.classList.contains('active')) {
                    nav.classList.remove('active');
                }
            }
        });
    });
    
    // Мобильное меню
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            nav.classList.toggle('active');
        });
    }
    
    // Закрытие меню при клике вне его
    document.addEventListener('click', (e) => {
        if (!nav.contains(e.target) && !menuToggle.contains(e.target) && nav.classList.contains('active')) {
            nav.classList.remove('active');
        }
    });
}

// Профиль пользователя
function initUserProfile() {
    const interestsContainer = document.getElementById('interestsContainer');
    
    // Отображаем интересы
    if (interestsContainer) {
        profileData.interests.forEach(interest => {
            const tag = document.createElement('span');
            tag.className = 'interest-tag';
            tag.textContent = interest;
            interestsContainer.appendChild(tag);
        });
    }
    
    // Обновляем контактную информацию
    updateContactInfo();
}

function updateContactInfo() {
    // Можно добавить динамическое обновление контактов при редактировании
    const emailElement = document.querySelector('.profile-contacts p:nth-child(2)');
    const telegramElement = document.querySelector('.profile-contacts p:nth-child(3)');
    
    if (emailElement) {
        emailElement.innerHTML = `<i class="fas fa-envelope"></i> ${profileData.contacts.email}`;
    }
    
    if (telegramElement) {
        telegramElement.innerHTML = `<i class="fab fa-telegram"></i> ${profileData.contacts.telegram}`;
    }
}

// Виджеты
function initDashboardWidgets() {
    const widgetsContainer = document.getElementById('dashboardWidgets');
    
    if (!widgetsContainer) return;
    
    // Виджет 1: Средний балл
    const widget1 = createWidget({
        icon: 'fas fa-chart-line',
        title: 'Текущий средний балл',
        value: `${widgetsData.averageScore}`,
        details: 'По всем модулям курса',
        color: 'success'
    });
    
    // Виджет 2: Следующий дедлайн
    const widget2 = createWidget({
        icon: 'fas fa-calendar-alt',
        title: 'Следующий дедлайн',
        value: `${widgetsData.nextDeadline.daysLeft} дн.`,
        details: `${widgetsData.nextDeadline.task}<br>До ${widgetsData.nextDeadline.date}`,
        color: 'warning'
    });
    
    // Виджет 3: Новые комментарии
    const widget3 = createWidget({
        icon: 'fas fa-comments',
        title: 'Новые комментарии',
        value: `${widgetsData.newComments}`,
        details: 'От преподавателя к вашим работам',
        color: 'info'
    });
    
    // Виджет 4: Рекомендуемая лекция
    const widget4 = createWidget({
        icon: 'fas fa-play-circle',
        title: 'Рекомендуемая лекция',
        value: 'Смотреть',
        details: `${widgetsData.recommendedLecture.title}<br>Лектор: ${widgetsData.recommendedLecture.lecturer}`,
        color: 'primary'
    });
    
    widgetsContainer.innerHTML = '';
    widgetsContainer.appendChild(widget1);
    widgetsContainer.appendChild(widget2);
    widgetsContainer.appendChild(widget3);
    widgetsContainer.appendChild(widget4);
}

function createWidget(config) {
    const widget = document.createElement('div');
    widget.className = 'widget';
    
    const colorClass = `widget-${config.color}`;
    widget.classList.add(colorClass);
    
    widget.innerHTML = `
        <div class="widget-header">
            <div class="widget-icon">
                <i class="${config.icon}"></i>
            </div>
            <span class="widget-title">${config.title}</span>
        </div>
        <div class="widget-value">${config.value}</div>
        <div class="widget-details">${config.details}</div>
    `;
    
    // Добавляем обработчик клика для виджета с лекцией
    if (config.icon.includes('play-circle')) {
        widget.style.cursor = 'pointer';
        widget.addEventListener('click', () => {
            alert(`Рекомендуется к просмотру: ${widgetsData.recommendedLecture.title}`);
        });
    }
    
    return widget;
}

// График успеваемости
function initProgressChart() {
    const chartContainer = document.getElementById('progressChart');
    
    if (!chartContainer) return;
    
    // Создаем простую круговую диаграмму с помощью CSS
    const totalScore = progressData.reduce((sum, module) => sum + module.total, 0);
    const totalMaxScore = progressData.reduce((sum, module) => sum + module.maxTotal, 0);
    const percentage = Math.round((totalScore / totalMaxScore) * 100);
    
    chartContainer.innerHTML = `
        <div class="chart-circle">
            <div class="chart-progress" style="--progress: ${percentage}%">
                <span class="chart-value">${percentage}%</span>
            </div>
            <div class="chart-info">
                <h4>Общий прогресс</h4>
                <p>${totalScore} из ${totalMaxScore} баллов</p>
                <div class="chart-legend">
                    <div class="legend-item">
                        <span class="legend-color" style="background: var(--primary-color)"></span>
                        <span>Выполнено</span>
                    </div>
                    <div class="legend-item">
                        <span class="legend-color" style="background: var(--border-color)"></span>
                        <span>Осталось</span>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Добавляем стили для диаграммы
    const style = document.createElement('style');
    style.textContent = `
        .chart-circle {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .chart-progress {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: conic-gradient(
                var(--primary-color) 0% calc(var(--progress)),
                var(--border-color) calc(var(--progress)) 100%
            );
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .chart-progress::before {
            content: '';
            position: absolute;
            width: 160px;
            height: 160px;
            background: white;
            border-radius: 50%;
        }
        
        .chart-value {
            position: relative;
            z-index: 1;
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .chart-info {
            text-align: center;
        }
        
        .chart-info h4 {
            margin-bottom: 10px;
            color: var(--primary-color);
        }
        
        .chart-legend {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 15px;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .legend-color {
            width: 12px;
            height: 12px;
            border-radius: 50%;
        }
    `;
    
    chartContainer.appendChild(style);
}

// Таблица успеваемости
function initProgressTable() {
    const table = document.getElementById('progressTable');
    
    if (!table) return;
    
    let tableHTML = `
        <thead>
            <tr>
                <th>Модуль</th>
                <th>Задания</th>
                <th>Баллы</th>
                <th>Итог</th>
                <th>Прогресс</th>
            </tr>
        </thead>
        <tbody>
    `;
    
    progressData.forEach(module => {
        const progressPercentage = Math.round((module.total / module.maxTotal) * 100);
        let progressClass = '';
        
        if (progressPercentage >= 90) progressClass = 'score-high';
        else if (progressPercentage >= 70) progressClass = 'score-medium';
        else progressClass = 'score-low';
        
        tableHTML += `
            <tr>
                <td><strong>${module.module}</strong></td>
                <td>
                    ${module.assignments.map(a => 
                        `<div>${a.name}: ${a.score}/${a.maxScore}</div>`
                    ).join('')}
                </td>
                <td>${module.total}/${module.maxTotal}</td>
                <td><span class="score ${progressClass}">${progressPercentage}%</span></td>
                <td>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${progressPercentage}%;"></div>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tableHTML += '</tbody>';
    table.innerHTML = tableHTML;
    
    // Добавляем стили для прогресс-баров
    const style = document.createElement('style');
    style.textContent = `
        .progress-bar {
            width: 100%;
            height: 8px;
            background: var(--border-color);
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--secondary-color), var(--primary-color));
            border-radius: 4px;
            transition: width 1s ease;
        }
    `;
    
    table.appendChild(style);
}

// Библиотека
function initLibrary() {
    const libraryGrid = document.getElementById('libraryGrid');
    const searchInput = document.getElementById('librarySearch');
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    if (!libraryGrid) return;
    
    // Функция отрисовки материалов
    function renderLibrary(materials) {
        libraryGrid.innerHTML = '';
        
        materials.forEach(material => {
            const materialCard = document.createElement('div');
            materialCard.className = 'material-card';
            materialCard.dataset.category = material.category;
            
            let icon = 'fas fa-file';
            if (material.type.includes('ppt')) icon = 'fas fa-file-powerpoint';
            else if (material.type === 'pdf') icon = 'fas fa-file-pdf';
            
            materialCard.innerHTML = `
                <div class="material-icon">
                    <i class="${icon}"></i>
                </div>
                <h3 class="material-title">${material.title}</h3>
                <div class="material-meta">
                    <span>${material.size}</span>
                    <span>${material.date}</span>
                </div>
                <button class="btn-secondary download-btn" style="margin-top: 15px; width: 100%;">
                    <i class="fas fa-download"></i> Скачать
                </button>
            `;
            
            libraryGrid.appendChild(materialCard);
        });
    }
    
    // Инициализация с данными
    renderLibrary(libraryData);
    
    // Поиск
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const filtered = libraryData.filter(material => 
                material.title.toLowerCase().includes(searchTerm)
            );
            renderLibrary(filtered);
        });
    }
    
    // Фильтрация по категориям
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Обновляем активную кнопку
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            const category = this.dataset.category;
            
            if (category === 'all') {
                renderLibrary(libraryData);
            } else {
                const filtered = libraryData.filter(material => 
                    material.category === category
                );
                renderLibrary(filtered);
            }
        });
    });
}

// Лекционный зал
function initLectures() {
    const lecturesGrid = document.getElementById('lecturesGrid');
    
    if (!lecturesGrid) return;
    
    lecturesGrid.innerHTML = '';
    
    lecturesData.forEach(lecture => {
        const lectureCard = document.createElement('div');
        lectureCard.className = 'lecture-card';
        
        let previewColor = 'var(--primary-color)';
        if (lecture.progress === 100) previewColor = 'var(--success-color)';
        else if (lecture.progress > 0) previewColor = 'var(--secondary-color)';
        
        lectureCard.innerHTML = `
            <div class="lecture-preview" style="background: linear-gradient(135deg, ${previewColor}, ${previewColor}80)">
                <i class="fas fa-play-circle"></i>
                <div class="lecture-progress">
                    <div class="lecture-progress-bar" style="width: ${lecture.progress}%"></div>
                </div>
            </div>
            <div class="lecture-info">
                <h3 class="lecture-title">${lecture.title}</h3>
                <p>Лектор: ${lecture.lecturer}</p>
                <div class="lecture-details">
                    <span><i class="far fa-clock"></i> ${lecture.duration}</span>
                    <span class="progress-text">Просмотрено: ${lecture.progress}%</span>
                </div>
                <button class="btn-primary watch-btn" style="width: 100%; margin-top: 15px;">
                    <i class="fas fa-play"></i> ${lecture.progress > 0 ? 'Продолжить' : 'Начать просмотр'}
                </button>
            </div>
        `;
        
        lecturesGrid.appendChild(lectureCard);
    });
}

// Задания
function initTasks() {
    const pendingTasksContainer = document.getElementById('pendingTasks');
    
    if (!pendingTasksContainer) return;
    
    pendingTasksContainer.innerHTML = '';
    
    tasksData.pending.forEach(task => {
        const taskCard = document.createElement('div');
        taskCard.className = `task-card ${task.status}`;
        
        const statusText = task.status === 'pending' ? 'Ждет выполнения' : 'В работе';
        const statusClass = task.status === 'pending' ? 'status-pending' : 'status-in-progress';
        
        taskCard.innerHTML = `
            <div class="task-status ${statusClass}">${statusText}</div>
            <h3>${task.title}</h3>
            <p>${task.description}</p>
            <div class="task-deadline">
                <i class="far fa-calendar-alt"></i> Дедлайн: ${task.deadline}
            </div>
            <button class="btn-primary start-task-btn" data-task-id="${task.id}" style="width: 100%;">
                <i class="fas fa-play-circle"></i> ${task.status === 'pending' ? 'Приступить' : 'Продолжить'}
            </button>
        `;
        
        pendingTasksContainer.appendChild(taskCard);
    });
}

// Форма загрузки
function initUploadForm() {
    const uploadForm = document.getElementById('uploadForm');
    const fileDropArea = document.getElementById('fileDropArea');
    const fileInput = document.getElementById('fileInput');
    const fileList = document.getElementById('fileList');
    const taskSelect = document.getElementById('taskSelect');
    
    if (!uploadForm) return;
    
    // Заполняем список заданий
    if (taskSelect) {
        tasksData.pending.forEach(task => {
            const option = document.createElement('option');
            option.value = task.id;
            option.textContent = `${task.title} (до ${task.deadline})`;
            taskSelect.appendChild(option);
        });
    }
    
    // Drag and drop файлов
    if (fileDropArea && fileInput) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            fileDropArea.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            fileDropArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            fileDropArea.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            fileDropArea.classList.add('dragover');
        }
        
        function unhighlight() {
            fileDropArea.classList.remove('dragover');
        }
        
        fileDropArea.addEventListener('drop', handleDrop, false);
        fileDropArea.addEventListener('click', () => fileInput.click());
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            handleFiles(files);
        }
        
        fileInput.addEventListener('change', function() {
            handleFiles(this.files);
        });
    }
    
    function handleFiles(files) {
        fileList.innerHTML = '';
        
        Array.from(files).forEach(file => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            
            const fileSize = (file.size / (1024 * 1024)).toFixed(2);
            
            fileItem.innerHTML = `
                <div>
                    <i class="fas fa-file"></i>
                    <span>${file.name} (${fileSize} MB)</span>
                </div>
                <button type="button" class="remove-file-btn" style="background: none; border: none; color: var(--danger-color); cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            fileList.appendChild(fileItem);
            
            // Кнопка удаления файла
            const removeBtn = fileItem.querySelector('.remove-file-btn');
            removeBtn.addEventListener('click', () => {
                fileItem.remove();
            });
        });
    }
    
    // Отправка формы
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const taskId = taskSelect.value;
        const workLink = document.getElementById('workLink').value;
        const comment = document.getElementById('workComment').value;
        
        if (!taskId || (!workLink && fileList.children.length === 0)) {
            alert('Пожалуйста, выберите задание и добавьте ссылку или файл работы');
            return;
        }
        
        // Имитация отправки
        showUploadSuccess();
        
        // Очистка формы
        uploadForm.reset();
        fileList.innerHTML = '';
    });
}

function showUploadSuccess() {
    // Создаем сообщение об успехе
    const successMsg = document.createElement('div');
    successMsg.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--success-color);
        color: white;
        padding: 15px 25px;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        z-index: 3000;
        animation: slideIn 0.3s ease;
    `;
    
    successMsg.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span style="margin-left: 10px;">Работа успешно отправлена на проверку!</span>
    `;
    
    document.body.appendChild(successMsg);
    
    // Убираем сообщение через 5 секунд
    setTimeout(() => {
        successMsg.style.opacity = '0';
        setTimeout(() => successMsg.remove(), 300);
    }, 5000);
}

// Архив работ
function initArchiveTable() {
    const archiveTable = document.getElementById('archiveTable');
    
    if (!archiveTable) return;
    
    let tableHTML = `
        <thead>
            <tr>
                <th>Название работы</th>
                <th>Дата сдачи</th>
                <th>Статус</th>
                <th>Оценка</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
    `;
    
    tasksData.archive.forEach(work => {
        let statusBadge = '';
        
        switch(work.status) {
            case 'graded':
                statusBadge = `<span class="status-badge status-graded">Оценено</span>`;
                break;
            case 'accepted':
                statusBadge = `<span class="status-badge status-accepted">Принято</span>`;
                break;
            case 'revision':
                statusBadge = `<span class="status-badge status-revision">На доработке</span>`;
                break;
        }
        
        tableHTML += `
            <tr>
                <td><strong>${work.title}</strong></td>
                <td>${work.submissionDate}</td>
                <td>${statusBadge}</td>
                <td>${work.score}</td>
                <td>
                    <button class="btn-secondary view-work-btn" data-work-id="${work.id}" style="margin-right: 8px;">
                        <i class="fas fa-eye"></i> Просмотреть
                    </button>
                    <button class="btn-secondary download-work-btn" data-work-id="${work.id}">
                        <i class="fas fa-download"></i> Скачать
                    </button>
                </td>
            </tr>
        `;
    });
    
    tableHTML += '</tbody>';
    archiveTable.innerHTML = tableHTML;
}

// Модальное окно редактирования профиля
function initModal() {
    const editProfileBtn = document.getElementById('editProfileBtn');
    const editProfileModal = document.getElementById('editProfileModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const cancelEditBtn = document.getElementById('cancelEditBtn');
    const saveProfileBtn = document.getElementById('saveProfileBtn');
    const editInterests = document.getElementById('editInterests');
    const editEmail = document.getElementById('editEmail');
    const editTelegram = document.getElementById('editTelegram');
    
    if (!editProfileBtn || !editProfileModal) return;
    
    // Открытие модального окна
    editProfileBtn.addEventListener('click', () => {
        // Заполняем поля текущими данными
        if (editInterests) {
            editInterests.value = profileData.interests.join(', ');
        }
        
        if (editEmail) {
            editEmail.value = profileData.contacts.email;
        }
        
        if (editTelegram) {
            editTelegram.value = profileData.contacts.telegram;
        }
        
        editProfileModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    });
    
    // Закрытие модального окна
    function closeModal() {
        editProfileModal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
    
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
    if (cancelEditBtn) cancelEditBtn.addEventListener('click', closeModal);
    
    // Закрытие при клике вне модального окна
    editProfileModal.addEventListener('click', (e) => {
        if (e.target === editProfileModal) {
            closeModal();
        }
    });
    
    // Сохранение изменений
    if (saveProfileBtn) {
        saveProfileBtn.addEventListener('click', () => {
            // Обновляем данные профиля
            if (editInterests) {
                const newInterests = editInterests.value.split(',').map(i => i.trim()).filter(i => i);
                profileData.interests = newInterests;
                
                // Обновляем отображение интересов
                const interestsContainer = document.getElementById('interestsContainer');
                if (interestsContainer) {
                    interestsContainer.innerHTML = '';
                    newInterests.forEach(interest => {
                        const tag = document.createElement('span');
                        tag.className = 'interest-tag';
                        tag.textContent = interest;
                        interestsContainer.appendChild(tag);
                    });
                }
            }
            
            if (editEmail) {
                profileData.contacts.email = editEmail.value;
            }
            
            if (editTelegram) {
                profileData.contacts.telegram = editTelegram.value;
            }
            
            // Обновляем контакты на странице
            updateContactInfo();
            
            // Показываем уведомление
            showProfileUpdateSuccess();
            
            // Закрываем модальное окно
            closeModal();
        });
    }
}

function showProfileUpdateSuccess() {
    const successMsg = document.createElement('div');
    successMsg.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--success-color);
        color: white;
        padding: 15px 25px;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        z-index: 3000;
        animation: slideIn 0.3s ease;
    `;
    
    successMsg.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span style="margin-left: 10px;">Профиль успешно обновлен!</span>
    `;
    
    document.body.appendChild(successMsg);
    
    setTimeout(() => {
        successMsg.style.opacity = '0';
        setTimeout(() => successMsg.remove(), 300);
    }, 3000);
}

// Обновление аватара
function updateUserAvatar() {
    const userAvatar = document.getElementById('userAvatar');
    const profileAvatar = document.getElementById('profileAvatar');
    
    if (userAvatar) {
        userAvatar.textContent = profileData.avatarInitials;
    }
    
    if (profileAvatar) {
        profileAvatar.textContent = profileData.avatarInitials;
    }
}

// Выход из системы
function initLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            // Очищаем сессию
            sessionStorage.clear();
            
            // Перенаправляем на страницу входа
            window.location.href = 'auth.html';
        });
    }
}

// ===== ЗАПУСК ПРИЛОЖЕНИЯ =====

// Запускаем инициализацию при полной загрузке DOM
document.addEventListener('DOMContentLoaded', initApp);

// Добавляем глобальные стили для анимаций
const globalStyles = document.createElement('style');
globalStyles.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
`;
document.head.appendChild(globalStyles);