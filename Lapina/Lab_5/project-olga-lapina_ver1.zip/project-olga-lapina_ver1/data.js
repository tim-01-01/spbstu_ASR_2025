// Данные профиля студента
const profileData = {
    fullName: "Лапина Ольга Константиновна",
    group: "5040102/50201",
    program: "Прикладная математика и информатика. Математические методы анализа и визуализации данных",
    level: "магистратура",
    course: "Автоматизация научных исследований",
    interests: [
        "Язык Python",
        "Автоматизация экспериментов",
        "Анализ данных",
        "Параметрическое исследование моделей",
        "Машинное обучение",
        "Визуализация научных результатов"
    ],
    contacts: {
        email: "lapina.ok@edu.spbstu.ru",
        telegram: "@olga_lapina_telegtam"
    },
    avatarInitials: "ОЛ"
};

// Данные успеваемости
const progressData = [
    {
        module: "Генерация аннотаций",
        assignments: [
            { name: "Задание 1: Базовые аннотации", score: 95, maxScore: 100 },
            { name: "Задание 2: Расширенные аннотации", score: 88, maxScore: 100 }
        ],
        total: 183,
        maxTotal: 200
    },
    {
        module: "Перевод аннотации на английский язык",
        assignments: [
            { name: "Перевод технического текста", score: 92, maxScore: 100 },
            { name: "Академический перевод", score: 85, maxScore: 100 }
        ],
        total: 177,
        maxTotal: 200
    },
    {
        module: "Генерация диаграмм UML",
        assignments: [
            { name: "Диаграмма классов", score: 98, maxScore: 100 },
            { name: "Диаграмма последовательности", score: 90, maxScore: 100 }
        ],
        total: 188,
        maxTotal: 200
    },
    {
        module: "Анализ научного текста",
        assignments: [
            { name: "Анализ структуры статьи", score: 87, maxScore: 100 },
            { name: "Выводы и интерпретация", score: 91, maxScore: 100 }
        ],
        total: 178,
        maxTotal: 200
    },
    {
        module: "Лендинг страницы",
        assignments: [
            { name: "Прототип интерфейса", score: 96, maxScore: 100 },
            { name: "Адаптивная верстка", score: 94, maxScore: 100 }
        ],
        total: 190,
        maxTotal: 200
    },
    {
        module: "Анализ источников",
        assignments: [
            { name: "Библиографический анализ", score: 89, maxScore: 100 },
            { name: "Систематизация источников", score: 93, maxScore: 100 }
        ],
        total: 182,
        maxTotal: 200
    },
    {
        module: "Поиск источников",
        assignments: [
            { name: "Поиск в базах данных", score: 90, maxScore: 100 },
            { name: "Оценка релевантности", score: 86, maxScore: 100 }
        ],
        total: 176,
        maxTotal: 200
    }
];

// Данные виджетов
const widgetsData = {
    averageScore: 91.4,
    nextDeadline: {
        task: "Финальный проект: Автоматизация анализа данных",
        date: "2024-12-20",
        daysLeft: 10
    },
    newComments: 3,
    recommendedLecture: {
        title: "Автоматизация научных экспериментов с Python",
        lecturer: "Проф. Иванов А.П.",
        duration: "45 мин"
    }
};

// Данные библиотеки
const libraryData = [
    {
        id: 1,
        title: "Методическое пособие по Python для научных исследований",
        category: "methodics",
        type: "pdf",
        size: "2.4 MB",
        date: "15.09.2024"
    },
    {
        id: 2,
        title: "Презентация: Основы автоматизации исследований",
        category: "presentations",
        type: "ppt",
        size: "5.1 MB",
        date: "22.09.2024"
    },
    {
        id: 3,
        title: "Методичка по работе с Jupyter Notebook",
        category: "methodics",
        type: "pdf",
        size: "1.8 MB",
        date: "01.10.2024"
    },
    {
        id: 4,
        title: "Презентация: Визуализация данных в исследованиях",
        category: "presentations",
        type: "pptx",
        size: "7.2 MB",
        date: "10.10.2024"
    },
    {
        id: 5,
        title: "Руководство по использованию Git для научных проектов",
        category: "methodics",
        type: "pdf",
        size: "3.2 MB",
        date: "18.10.2024"
    },
    {
        id: 6,
        title: "Презентация: Автоматизация обработки текстов",
        category: "presentations",
        type: "pptx",
        size: "4.5 MB",
        date: "25.10.2024"
    }
];

// Данные лекций
const lecturesData = [
    {
        id: 1,
        title: "Введение в автоматизацию научных исследований",
        lecturer: "Проф. Петров С.М.",
        duration: "38 мин",
        progress: 100
    },
    {
        id: 2,
        title: "Python для научных вычислений",
        lecturer: "Доц. Сидорова Е.В.",
        duration: "52 мин",
        progress: 85
    },
    {
        id: 3,
        title: "Автоматизация сбора данных",
        lecturer: "Проф. Иванов А.П.",
        duration: "47 мин",
        progress: 60
    },
    {
        id: 4,
        title: "Обработка и анализ экспериментальных данных",
        lecturer: "Доц. Кузнецова О.И.",
        duration: "61 мин",
        progress: 30
    },
    {
        id: 5,
        title: "Визуализация научных результатов",
        lecturer: "Проф. Смирнов Д.К.",
        duration: "44 мин",
        progress: 0
    },
    {
        id: 6,
        title: "Интеграция инструментов для исследований",
        lecturer: "Проф. Петров С.М.",
        duration: "56 мин",
        progress: 0
    }
];

// Данные заданий
const tasksData = {
    pending: [
        {
            id: 1,
            title: "Финальный проект: Автоматизация анализа данных",
            description: "Разработать систему автоматического анализа научных данных",
            deadline: "2024-12-20",
            status: "pending",
            priority: "high"
        },
        {
            id: 2,
            title: "Оптимизация алгоритма обработки",
            description: "Улучшение производительности существующего алгоритма",
            deadline: "2024-12-15",
            status: "in-progress",
            priority: "medium"
        }
    ],
    archive: [
        {
            id: 101,
            title: "Генератор UML-диаграмм",
            submissionDate: "2024-11-25",
            status: "graded",
            score: "95/100",
            files: ["uml_generator.zip"]
        },
        {
            id: 102,
            title: "Анализатор научных текстов",
            submissionDate: "2024-11-18",
            status: "graded",
            score: "88/100",
            files: ["text_analyzer.py"]
        },
        {
            id: 103,
            title: "Система аннотирования статей",
            submissionDate: "2024-11-10",
            status: "graded",
            score: "92/100",
            files: ["annotation_system.zip"]
        },
        {
            id: 104,
            title: "Модуль визуализации данных",
            submissionDate: "2024-11-05",
            status: "accepted",
            score: "-",
            files: ["visualization_module.py"]
        }
    ]
};

// Демо-данные для аутентификации
const authCredentials = {
    login: "lapina.ok",
    password: "study2024"
};