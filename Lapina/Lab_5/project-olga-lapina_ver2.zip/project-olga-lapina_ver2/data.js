// Данные профиля студента
const profileData = {
    fullName: "Лапина Ольга Константиновна",
    group: "5040102/50201",
    program: "Прикладная математика и информатика. Математические методы анализа и визуализации данных",
    level: "магистратура",
    course: "Автоматизация научных исследований",
    interests: [
        "Язык Python",
        "Автоматизация экспериментов",
        "Анализ данных",
        "Параметрическое исследование моделей",
        "Машинное обучение",
        "Визуализация научных результатов"
    ],
    contacts: {
        email: "lapina.ok@edu.spbstu.ru",
        telegram: "@olga_lapina_telegtam"
    },
    avatarInitials: "ОЛ"
};

// Данные успеваемости
const progressData = [
    {
        module: "Генерация аннотаций",
        assignments: [
            { name: "Задание 1: Базовые аннотации", score: 95, maxScore: 100 },
            { name: "Задание 2: Расширенные аннотации", score: 88, maxScore: 100 }
        ],
        total: 183,
        maxTotal: 200
    },
    {
        module: "Перевод аннотации на английский язык",
        assignments: [
            { name: "Перевод технического текста", score: 92, maxScore: 100 },
            { name: "Академический перевод", score: 85, maxScore: 100 }
        ],
        total: 177,
        maxTotal: 200
    },
    {
        module: "Генерация диаграмм UML",
        assignments: [
            { name: "Диаграмма классов", score: 98, maxScore: 100 },
            { name: "Диаграмма последовательности", score: 90, maxScore: 100 }
        ],
        total: 188,
        maxTotal: 200
    },
    {
        module: "Анализ научного текста",
        assignments: [
            { name: "Анализ структуры статьи", score: 87, maxScore: 100 },
            { name: "Выводы и интерпретация", score: 91, maxScore: 100 }
        ],
        total: 178,
        maxTotal: 200
    },
    {
        module: "Лендинг страницы",
        assignments: [
            { name: "Прототип интерфейса", score: 96, maxScore: 100 },
            { name: "Адаптивная верстка", score: 94, maxScore: 100 }
        ],
        total: 190,
        maxTotal: 200
    },
    {
        module: "Анализ источников",
        assignments: [
            { name: "Библиографический анализ", score: 89, maxScore: 100 },
            { name: "Систематизация источников", score: 93, maxScore: 100 }
        ],
        total: 182,
        maxTotal: 200
    },
    {
        module: "Поиск источников",
        assignments: [
            { name: "Поиск в базах данных", score: 90, maxScore: 100 },
            { name: "Оценка релевантности", score: 86, maxScore: 100 }
        ],
        total: 176,
        maxTotal: 200
    }
];

// Данные виджетов
const widgetsData = {
    averageScore: 91.4,
    nextDeadline: {
        task: "Финальный проект: Автоматизация анализа данных",
        date: "2025-12-20",
        daysLeft: 10
    },
    newComments: 3,
    recommendedLecture: {
        title: "Автоматизация научных экспериментов с Python",
        lecturer: "Проф. Иванов А.П.",
        duration: "45 мин",
        module: "Генерация аннотаций"
    }
};

// Модули курса
const courseModules = [
    "Генерация аннотаций",
    "Перевод аннотации на английский язык", 
    "Генерация диаграмм UML",
    "Анализ научного текста",
    "Лендинг страницы",
    "Анализ источников",
    "Поиск источников"
];

// Данные библиотеки (только для текущего курса)
const libraryData = [
    {
        id: 1,
        title: "Методическое пособие по генерации аннотаций",
        module: "Генерация аннотаций",
        category: "annotation",
        type: "pdf",
        size: "2.4 MB",
        date: "15.09.2025",
        description: "Основные принципы и методы автоматической генерации аннотаций"
    },
    {
        id: 2,
        title: "Презентация: Автоматизация научных экспериментов",
        module: "Генерация аннотаций",
        category: "annotation",
        type: "ppt",
        size: "5.1 MB",
        date: "22.09.2025",
        description: "Техники автоматизации экспериментов с использованием Python"
    },
    {
        id: 3,
        title: "Руководство по переводу научных текстов",
        module: "Перевод аннотации на английский язык",
        category: "translation",
        type: "pdf",
        size: "1.8 MB",
        date: "01.10.2025",
        description: "Особенности перевода научных аннотаций на английский язык"
    },
    {
        id: 4,
        title: "Презентация: Генерация UML-диаграмм",
        module: "Генерация диаграмм UML",
        category: "uml",
        type: "pptx",
        size: "7.2 MB",
        date: "10.10.2025",
        description: "Автоматизация создания UML-диаграмм для научных проектов"
    },
    {
        id: 5,
        title: "Методичка по анализу научного текста",
        module: "Анализ научного текста",
        category: "analysis",
        type: "pdf",
        size: "3.2 MB",
        date: "18.10.2025",
        description: "Алгоритмы автоматического анализа структуры научных статей"
    },
    {
        id: 6,
        title: "Презентация: Создание лендинг страниц",
        module: "Лендинг страницы",
        category: "landing",
        type: "pptx",
        size: "4.5 MB",
        date: "25.10.2025",
        description: "Автоматизация создания образовательных лендингов"
    },
    {
        id: 7,
        title: "Руководство по анализу источников",
        module: "Анализ источников",
        category: "sources",
        type: "pdf",
        size: "2.9 MB",
        date: "02.11.2025",
        description: "Методы автоматического анализа научных источников"
    },
    {
        id: 8,
        title: "Презентация: Поиск научных источников",
        module: "Поиск источников",
        category: "search",
        type: "pptx",
        size: "3.8 MB",
        date: "09.11.2025",
        description: "Автоматизированный поиск релевантных научных источников"
    }
];

// Данные лекций (только для текущего курса)
const lecturesData = [
    {
        id: 1,
        title: "Введение в автоматизацию научных исследований",
        lecturer: "Проф. Петров С.М.",
        duration: "38 мин",
        progress: 100,
        module: "Генерация аннотаций"
    },
    {
        id: 2,
        title: "Автоматизация научных экспериментов с Python",
        lecturer: "Доц. Сидорова Е.В.",
        duration: "52 мин",
        progress: 85,
        module: "Генерация аннотаций"
    },
    {
        id: 3,
        title: "Автоматический перевод научных текстов",
        lecturer: "Проф. Иванов А.П.",
        duration: "47 мин",
        progress: 60,
        module: "Перевод аннотации на английский язык"
    },
    {
        id: 4,
        title: "Генерация UML-диаграмм для научных проектов",
        lecturer: "Доц. Кузнецова О.И.",
        duration: "61 мин",
        progress: 30,
        module: "Генерация диаграмм UML"
    },
    {
        id: 5,
        title: "Анализ структуры научных статей",
        lecturer: "Проф. Смирнов Д.К.",
        duration: "44 мин",
        progress: 0,
        module: "Анализ научного текста"
    },
    {
        id: 6,
        title: "Автоматизация создания лендинг страниц",
        lecturer: "Доц. Николаева М.В.",
        duration: "56 мин",
        progress: 0,
        module: "Лендинг страницы"
    },
    {
        id: 7,
        title: "Алгоритмы анализа научных источников",
        lecturer: "Проф. Петров С.М.",
        duration: "49 мин",
        progress: 0,
        module: "Анализ источников"
    },
    {
        id: 8,
        title: "Поиск релевантных научных источников",
        lecturer: "Доц. Сидорова Е.В.",
        duration: "53 мин",
        progress: 0,
        module: "Поиск источников"
    }
];

// Данные заданий
const tasksData = {
    pending: [
        {
            id: 1,
            title: "Автоматизация генерации аннотаций",
            description: "Разработать алгоритм автоматической генерации аннотаций для научных статей",
            deadline: "2025-12-20",
            status: "pending",
            priority: "high",
            module: "Генерация аннотаций"
        },
        {
            id: 2,
            title: "Перевод аннотаций на английский язык",
            description: "Создать систему автоматического перевода научных аннотаций",
            deadline: "2025-12-15",
            status: "in-progress",
            priority: "medium",
            module: "Перевод аннотации на английский язык"
        },
        {
            id: 3,
            title: "Генерация UML-диаграмм проекта",
            description: "Разработать инструмент для автоматической генерации UML-диаграмм",
            deadline: "2025-12-10",
            status: "pending",
            priority: "medium",
            module: "Генерация диаграмм UML"
        }
    ],
    archive: [
        {
            id: 101,
            title: "Анализ научного текста: Структура статьи",
            module: "Анализ научного текста",
            submissionDate: "2025-11-25",
            status: "graded",
            score: "95/100",
            files: ["text_analysis.zip"]
        },
        {
            id: 102,
            title: "Лендинг страницы научного проекта",
            module: "Лендинг страницы",
            submissionDate: "2025-11-18",
            status: "graded",
            score: "88/100",
            files: ["landing_project.zip"]
        },
        {
            id: 103,
            title: "Анализ библиографических источников",
            module: "Анализ источников",
            submissionDate: "2025-11-10",
            status: "graded",
            score: "92/100",
            files: ["sources_analysis.py"]
        },
        {
            id: 104,
            title: "Система поиска научных источников",
            module: "Поиск источников",
            submissionDate: "2025-11-05",
            status: "accepted",
            score: "-",
            files: ["source_search_system.py"]
        }
    ]
};

// Демо-данные для аутентификации
const authCredentials = {
    login: "lapina.ok",
    password: "study2025"
};